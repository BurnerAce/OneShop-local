import React from 'react';
import { Link } from 'react-router-dom';

const HomePage = () => {
    return (
        <div>
            <h2>Welcome!</h2>
            <p>Are you a customer or an owner?</p>
            <div>
                <Link to="/csignup">
                    <button>Customer Signup</button>
                </Link>
                <Link to="/osignup">
                    <button>Owner Signup</button>
                </Link>
            </div>
        </div>
    );
};

export default HomePage;
