import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import { useNavigate, Link } from 'react-router-dom';

const PreItems = () => {
    const navigate = useNavigate();
    const [searchTerm, setSearchTerm] = useState('');
    const storeRef = useRef(JSON.parse(localStorage.getItem('ownuser')));
    const [items, setItems] = useState([]);
    const [updatedItem, setUpdatedItem] = useState({});
    let user = JSON.parse(localStorage.getItem('ownuser'));
    user = user ? user : "NA";

    useEffect(() => {
        if (user === "NA") {
            alert("You Must Login First!");
            navigate('/ologin');
        }
    }, [navigate, user]);


    const fetchItems = async () => {
        if (storeRef.current) {
            try {
                const res = await axios.get(`http://localhost:5000/items?collect=${storeRef.current.collect}`);
                setItems(res.data.item);
                console.log(res.data.item);
            } catch (error) {
                console.error('Error fetching items:', error);
            }
        }
    };

    const deleteItem = async (itemId) => {
        try {
            await axios.delete(`http://localhost:5000/delItem?collect=${storeRef.current.collect}&itemId=${itemId}`);
            setItems(items.filter(item => item.name !== itemId));
        } catch (error) {
            console.error('Error deleting item:', error);
        }
    };

    useEffect(() => {
        fetchItems();
    }, []);

    const updateItem = async (itemId, updatedData) => {
        try {
            await axios.put(`http://localhost:5000/update?collect=${storeRef.current.collect}&itemId=${itemId}`, updatedData);
            fetchItems();
        } catch (error) {
            console.error('Error updating item:', error);
        }
    };

    if (user === "NA") {
        return null;
    }

    return (
        <div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <h1>{storeRef.current.shop} Items</h1>
                <h4>{storeRef.current.name} <Link to="/ologout">Logout</Link></h4>
            </div>
            <Link to="/add">
                <button>Add New Item</button>
            </Link>
            <Link to="/orders">
                <button>Check Your Orders</button>
            </Link>
            <hr></hr>
            <input type="text" placeholder="Search..." onChange={(e) => setSearchTerm(e.target.value)} />
            {items.filter(item => item.name.toLowerCase().includes(searchTerm.toLowerCase())).map(item => (
                <div key={item.id}>
                    <h2>{item.name}</h2>
                    <img src={item.image} alt={item.name} style={{ width: '100px', height: '100px' }} />
                    <p>{item.description}</p>
                    <p>{item.category}</p>
                    <p>Price: Rs {item.price}</p>
                    <p>Available Quantity: {item.quantity}</p>
                    {item.quantity === 0 ? <p>Out of Stock</p> : item.quantity < 10 ? <p>Only few pieces left</p> : null}
                    <button onClick={() => deleteItem(item.name)}>Delete</button>
                    <br></br>
                    <br></br>
                    <form onSubmit={(e) => {
                        e.preventDefault();
                        const newQuantity = updatedItem.quantity !== '' ? updatedItem.quantity : item.quantity;
                        const newPrice = updatedItem.price !== '' ? updatedItem.price : item.price;
                        updateItem(item.name, { price: newPrice, quantity: newQuantity });
                    }}>
                        <input
                            type="number"
                            placeholder="New Price"
                            value={updatedItem.price || ''}
                            onChange={(e) => setUpdatedItem({ ...updatedItem, price: e.target.value })}
                        />
                        <input
                            type="number"
                            placeholder="New Quantity"
                            value={updatedItem.quantity || ''}
                            onChange={(e) => setUpdatedItem({ ...updatedItem, quantity: e.target.value })}
                        />
                        <button type="submit">Update</button>
                    </form>
                </div>
            ))}
        </div>
    );
};

export default PreItems;