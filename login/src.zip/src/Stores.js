import React , {useEffect} from 'react';
import { useNavigate ,  Link } from 'react-router-dom';

const Stores = () => {

    const navigate=useNavigate();
    let user = JSON.parse(localStorage.getItem('custuser'));
    const stores = JSON.parse(localStorage.getItem('custstores'));
    user = user ? user : "NA";

    useEffect(() => {
        if(user === "NA"){
            alert("You Must Login First!");
            navigate('/clogin');
        }
    }, [navigate, user]);

    const calculateDistance = (coords1, coords2) => {
        const R = 6371; // Radius of the earth in km
        const dLat = deg2rad(coords2.latitude - coords1.latitude);
        const dLon = deg2rad(coords2.longitude - coords1.longitude);
        const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(deg2rad(coords1.latitude)) * Math.cos(deg2rad(coords2.latitude)) *
            Math.sin(dLon / 2) * Math.sin(dLon / 2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return R * c; // Distance in km
    };

    const deg2rad = (deg) => {
        return deg * (Math.PI / 180);
    };

    if(user==="NA"){
        return null;
    }

    return (
        <div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <h1>Stores</h1>
                <h4>{user.name} <Link to="/logout">Logout</Link></h4>

            </div>
            <p>
            <Link to="/checkout">
                <button>Check Your Orders</button>
            </Link>
            </p>
            {stores.map((store) => (
                <div key={store.name} style={{ backgroundImage: `url(${store.back_img})`, padding: '20px', margin: '10px', borderRadius: '5px' }}>
                    <h2>{store.shop}</h2>
                    <p>{store.phone}</p>
                    <p>{store.location}</p>
                    <p>Distance: {calculateDistance(user.coordinates, store.coordinates).toFixed(3)} km</p>
                    <Link
                        to={{ pathname: '/items' }}
                        onClick={() => {
                            const currentStore = JSON.parse(localStorage.getItem('custstore'));
                            if (JSON.stringify(currentStore) !== JSON.stringify(store)) {
                                localStorage.setItem('custstore', JSON.stringify(store));
                            }
                        }}
                    >
                        View Items
                    </Link>
                </div>
            ))}
        </div>
    );

};

export default Stores;
