import React from 'react';
import { useNavigate } from 'react-router-dom';

const OLogout = () => {
    const navigate = useNavigate();

    const handleLogout = () => {
        // Clear local storage
        localStorage.removeItem('ownuser');

        // Redirect to login page
        navigate('/ologin');
    };

    return (
        <button onClick={handleLogout}>Logout</button>
    );
};

export default OLogout;
